package com.himanshu.demo.service;

import java.util.List;

import com.himanshu.demo.bean.EmployeeBean;
import com.himanshu.demo.bean.ManagerBean;


public interface ManagerService {
	List<ManagerBean> get();

	EmployeeBean get(int id);

	void save(ManagerBean manager);

	void delete(int id);
}

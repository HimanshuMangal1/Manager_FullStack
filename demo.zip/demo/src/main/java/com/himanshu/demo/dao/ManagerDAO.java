package com.himanshu.demo.dao;

import java.util.List;

import com.himanshu.demo.bean.ManagerBean;


public interface ManagerDAO {

	boolean checkIfExistInDb(String username,String password);
	
	List<ManagerBean> get();

	ManagerBean get(int id);

	void save(ManagerBean employee);

	void delete(int id);
}

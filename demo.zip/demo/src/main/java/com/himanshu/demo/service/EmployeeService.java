package com.himanshu.demo.service;

import java.util.List;

import com.himanshu.demo.bean.EmployeeBean;


public interface EmployeeService {
	List<EmployeeBean> get();

	EmployeeBean get(int id);

	void save(EmployeeBean employee);

	void delete(int id);
}


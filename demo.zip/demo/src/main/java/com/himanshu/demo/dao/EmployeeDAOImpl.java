package com.himanshu.demo.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.himanshu.demo.bean.EmployeeBean;


@Repository
public class EmployeeDAOImpl implements EmployeeDAO{

	@Autowired
	private EntityManager entityManager;
	@Override
	public List<EmployeeBean> get() {
		Session currentSession = entityManager.unwrap(Session.class);
		Query<EmployeeBean> query= currentSession.createQuery("from EmployeeBean",EmployeeBean.class);
		List<EmployeeBean> empList = query.getResultList();
		return empList;
	}
	@Override
	public EmployeeBean get(int empId) {
		Session currentSession = entityManager.unwrap(Session.class);
		EmployeeBean employee = currentSession.get(EmployeeBean.class, empId);
		return employee;
	}
	@Override
	public void save(EmployeeBean employee) {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(employee);
	}
	@Override
	public void delete(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
		EmployeeBean employee = currentSession.get(EmployeeBean.class, id);
		currentSession.delete(employee);
	}
}
